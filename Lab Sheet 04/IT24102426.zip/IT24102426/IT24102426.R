#Exercise

setwd("C:\\Users\\thish\\OneDrive\\Desktop\\IT24102426")

# Q1. Import data set
branch.data <- read.csv("Exercise.txt", header = TRUE)
head(branch.data)
# Open spreadsheet-like editor to view and manually check/edit data
fix(branch.data)
# Attach the data set (so we can access columns directly by name)
attach(branch.data)

# Q2. Identify variable type and scale
str(branch.data)
# Branch -> Categorical (Nominal)
# Sales_X1 -> Numeric (Ratio)
# Advertising_X2 -> Numeric (Ratio)
# Years_X3 -> Numeric (Ratio)

# 3. Boxplots
boxplot(Sales_X1,main="Box plot of Sales",col="lightgreen",ylab="Sales (X1)")

boxplot(Advertising_X2,main="Box plot of Advertising",col="lightblue",ylab="Advertising (X2)")

boxplot(Years_X3,main="Box plot of Years",col="lightpink",ylab="Years (X3)")

# 4. Five number summary and IQR for Advertising

summary(Advertising_X2)
IQR(Advertising_X2)

# 5. Function to detect outliers in Years
find_outliers <- function(x){
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  lower <- Q1 - 1.5*IQR_val
  upper <- Q3 + 1.5*IQR_val
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(Years_X3)

