#Exercise

setwd("C:\\Users\\thish\\OneDrive\\Desktop\\IT24102426")

# 1

#Import data set
Delivery_Times <- read.csv("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)
# view the file in a separate window
fix(Delivery_Times)
#call the variables by their names
attach(Delivery_Times)

# 2

#Create breaks for 9 class intervals from 20 to 70
breaks = seq(20,70,length.out = 10)
#Draw a histogram
histogram <- hist(Delivery_Time_.minutes., 
                  right = TRUE,
                  main = "Histogram of Delivery Times",
                  xlab = "Delivery_Time",
                  ylab = "Frequency",
                  col = "blue")
# 3
#Comment on the shape of the distribution
#The distribution is approximately symmetrical with a single peak around 40.  
#It is not heavily skewed to the left or right. Slight variations are normal.

# 4
#Draw cumulative frequency polygon (ogive)
Delivery_Times_freq <- hist(Delivery_Time_.minutes., breaks = breaks, plot = FALSE)

cum.freq <- cumsum(Delivery_Times_freq$counts)

#Plot ogive
plot(Delivery_Times_freq$mids, cum.freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency",
     col = "red",
     pch = 16)
