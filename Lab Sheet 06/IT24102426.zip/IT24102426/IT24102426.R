setwd("C:/Users/thish/OneDrive/Desktop/IT24102426")

#Q1: Binomial Distribution (Online Test Pass Rate)
#Success rate (p) = 0.85  
#Number of students (n) = 50  
#X = Number of students who passed

# -i-
#X ~ Binomial(n = 50, p = 0.85)

# -ii- 
pbinom(46, 50, 0.85, lower.tail = FALSE)
#or
1 - pbinom(46, 50, 0.85)  

#Q2: Poisson Distribution (Call Center)
#λ = 12 calls/hour  
#X = Number of calls received in an hour

# -i-
#X = Number of customer calls received in an hour

# -ii-
#X ~ Poisson(λ = 12)

# -iii- P(X = 15)
dpois(15, 12)

